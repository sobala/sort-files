import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;


@DisplayName("File Watcher Test Suite")
public class FileWatcherTestSuite {

    @BeforeEach
    public void before() {
        System.out.println("Test Case: begin");
    }

    @AfterEach
    public void after() {
        System.out.println("Test Case: end");
    }

    @DisplayName(
            "XML file should be moved from HOME to DEV folder."
    )
    @Test
    void testMovingXmlFile() throws ParserConfigurationException, IOException {
        //Given
        FileWatcher fileWatcher = new FileWatcher();
        fileWatcher.watchFolder();
        File myObj = new File("/HOME/testxml.xml");
        if (myObj.createNewFile()) {
            System.out.println("File created: " + myObj.getName());
        } else {
            System.out.println("File already exists.");
        }
        //When

        //Then

    }
}
