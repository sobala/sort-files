import org.apache.commons.io.FilenameUtils;
import java.io.IOException;
import java.nio.file.*;

public class FileWatcher {

    public void watchFolder() {

        try {

            System.out.println("Watching directory for changes");

            WatchService watchService = FileSystems.getDefault().newWatchService();

            Path directory = Path.of("/HOME");

            WatchKey watchKey = directory.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE);

            while (true) {
                for (WatchEvent<?> event : watchKey.pollEvents()) {

                    WatchEvent<Path> pathEvent = (WatchEvent<Path>) event;

                    Path fileName = pathEvent.context();

                    WatchEvent.Kind<?> kind = event.kind();

                    if (kind == StandardWatchEventKinds.ENTRY_CREATE) {

                        System.out.println("A new file has been created : " + fileName);
                        this.moveFile(fileName);

                    }
                }

                boolean valid = watchKey.reset();
                if (!valid) {
                    break;
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void moveFile(Path fileName) throws IOException {
        if (FilenameUtils.getExtension("filename").equals("xml")) {
            System.out.println("Moving xml file.");
            Path source = Path.of("/HOME/" + fileName);
            Path target = Path.of("/DEV/" + fileName);
            Files.move(source, target);
        } else if (FilenameUtils.getExtension("filename").equals("jar")) {
            System.out.println("Moving jar file.");
        }
    }

}
