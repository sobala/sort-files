import java.io.IOException;
import java.io.PrintWriter;

public class FileSorter {

    public static void main(String[] args) throws IOException {
        FolderCreator folderCreator = new FolderCreator();

        folderCreator.createFolder("/HOME");
        folderCreator.createFolder("/DEV");
        folderCreator.createFolder("/TEST");

        PrintWriter writer = new PrintWriter("/HOME/count.txt", "UTF-8");


        FileWatcher fileWatcher = new FileWatcher();
        fileWatcher.watchFolder();

        writer.close();
    }
}
