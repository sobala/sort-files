import java.io.File;

public class FolderCreator {

    public void createFolder(String path) {
        File file = new File(path);
        if(file.exists() == false) {
            boolean bool = file.mkdir();
            if(bool){
                System.out.println("Folder has been created successfully.");
            }else{
                System.out.println("Error while creating a folder.");
            }
        }
    }
}
